package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ServletFirst")
public class ServletFirst extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
  

	public void init(ServletConfig config) throws ServletException {
		
	}

	
	public void destroy() {
		
	}

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter writer=response.getWriter();
		writer.print("<html>");
		writer.print("	<head>");
		writer.print("<title>The First Servlet</title></head>");
		writer.print("<body><h2>First Page</h2> <form action='ServletSecond' method='post'> <table><tr><td>FirstName :</td><td><input type='text' name='firstName'></td></tr><tr><td>LastName         :</td><td><input type='text' name='lastName'></td></tr><tr ><td><input type='submit' name='submit'></td></tr> </form></body></html>");
		
	}

	


}
