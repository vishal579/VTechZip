package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ServletThird")
public class ServletThird extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
  

	public void init(ServletConfig config) throws ServletException {
		
	}

	
	public void destroy() {
		
	}

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter writer=response.getWriter();
		writer.print("<html>");
		writer.print("	<head>");
		writer.print("<title>The Third Servlet</title></head>");
		writer.print("<body><h2>Third Page</h2> <form action='ServletFourth' method='post'> "
				+ "<table>"
				+ "<tr>"
				+ "<td>FirstName :</td>"
				+ "<td></td></tr>"
				+ "<tr>"
				+ "<td>LastName:</td>"
				+ "<td></td></tr>"
				+ "<td>City:</td>"
				+ "<td></td></tr>"
				+ "<td>State:</td>"
				+ "<td></td></tr>"
				+ "<tr><td>Mobile Number     :</td>"
				+ "<td><input type='tel' name='mobileNumber'></td></tr>"
				+ "<tr><td>EmailId          :</td>"
				+ "<td><input type='email' name='emailId'></td></tr>"
				+ "<tr ><td><input type='submit' name='submit'></td></tr>"
				+ " </form></body></html>");
		
	}

	


}
