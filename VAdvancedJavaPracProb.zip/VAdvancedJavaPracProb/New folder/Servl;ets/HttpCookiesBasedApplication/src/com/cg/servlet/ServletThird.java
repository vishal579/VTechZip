package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.beans.UserBean;

@WebServlet("/ServletThird")
public class ServletThird extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
  

	public void init(){
		
	}

	
	public void destroy() {
		
	}

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String city=(String)request.getParameter("city");
		String state=(String)request.getParameter("state");
		Cookie [] cookies = request.getCookies();
		String firstName ="" , lastName="";
		for (Cookie cookie : cookies) {
			if(cookie.getName().equals("firstName"))
				firstName =cookie.getValue();
			else if(cookie.getName().equals("lastName"))
				lastName=cookie.getValue();
		}
		Cookie c3 = new  Cookie("city",city);
		Cookie c4 = new Cookie("state" ,state);
		response.addCookie(c3);
		response.addCookie(c4);
		
		PrintWriter writer=response.getWriter();
		writer.print("<html>");
		writer.print("	<head>");
		writer.print("<title>The Third Servlet</title></head>");
		writer.print("<body><h2>Third Page</h2> <form action='ServletFourth' method='post'> "
				+ "<table>"
				+ "<tr>"
				+ "<td>FirstName :</td>"
				+ "<td>"+firstName+"</td></tr>"
				+ "<tr>"
				+ "<td>LastName:</td>"
				+ "<td>"+lastName+"</td></tr>"
				+ "<td>City:</td>"
				+ "<td>"+city+"</td></tr>"
				+ "<td>State:</td>"
				+ "<td>"+state+"</td></tr>"
				+ "<tr><td>Mobile Number     :</td>"
				+ "<td><input type='tel' name='mobileNumber'></td></tr>"
				+ "<tr><td>EmailId          :</td>"
				+ "<td><input type='email' name='emailId'></td></tr>"
				+ "<tr ><td><input type='submit' name='submit'></td></tr>"
				+ " </form></body></html>");
		
	}

	


}
