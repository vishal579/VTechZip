package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.beans.UserBean;

@WebServlet("/ServletSecond")
public class ServletSecond extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
  

	public void init()  {
		
	}

	
	public void destroy() {
		
	}

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstName=(String) request.getParameter("firstName");
		String lastName=(String) request.getParameter("lastName");
		
		Cookie c1 = new  Cookie("firstName",firstName);
		Cookie c2 = new Cookie("lastName" ,lastName);
		response.addCookie(c1);
		response.addCookie(c2);
		
	
		
		PrintWriter writer=response.getWriter();
		writer.print("<html>");
		writer.print("	<head>");
		writer.print("<title>The Second Servlet</title></head>");
		writer.print("<body><h2>Second Page</h2> <form action='ServletThird' method='post'> "
				+ "<table>"
				+ "<tr>"
				+ "<td>FirstName :</td>"
				+ "<td>"+firstName+"</td></tr>"
				+ "<tr>"
				+ "<td>LastName:</td>"
				+ "<td>"+lastName+"</td></tr>"
				+ "<td>City:</td>"
				+ "<td><input type='text' name='city'></td></tr>"
				+ "<td>State:</td>"
				+ "<td><input type='text' name='state'></td></tr>"
				+ "<tr ><td><input type='submit' name='submit'></td></tr>"
				+ " </form></body></html>");
		
	}

	


}
