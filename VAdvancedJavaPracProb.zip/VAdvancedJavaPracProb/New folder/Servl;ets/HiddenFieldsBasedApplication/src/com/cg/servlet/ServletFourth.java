package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.FilterRegistration;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.beans.UserBean;

@WebServlet("/ServletFourth")
public class ServletFourth extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
  

	public void init() {
		
	}

	
	public void destroy() {
		
	}

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstName=(String) request.getParameter("firstName");
		String lastName=(String) request.getParameter("lastName");
		String city=(String)request.getParameter("city");
		String state=(String)request.getParameter("state");
		String emailId=(String)request.getParameter("emailId");
		String mobileNumber=(String)request.getParameter("mobileNumber");
		PrintWriter writer=response.getWriter();
		writer.print("<html>");
		writer.print("	<head>");
		writer.print("<title>The Fourth Servlet</title></head>");
		writer.print("<body><h2>Fourth Page</h2> <form action='' > "
				+ "<table>"
				+ "<tr>"
				+ "<td>FirstName :</td>"
				+ "<td>"+firstName+"</td></tr>"
				+ "<tr>"
				+ "<td>LastName:</td>"
				+ "<td>"+lastName +"</td></tr>"
				+ "<td>City:</td>"
				+ "<td>"+city+"</td></tr>"
				+ "<td>State:</td>"
				+ "<td>"+state +"</td></tr>"
				+ "<tr><td>Mobile Number     :</td>"
				+ "<td>"+mobileNumber +"</td></tr>"
				+ "<tr><td>EmailId          :</td>"
				+ "<td>"+emailId +"</td></tr>"
			
				+ " </form></body></html>");
		
	}

	


}
/*writer.print("<body><h2>Fourth Page</h2> <form action='' > "
				+ "<table>"
				+ "<tr>"
				+ "<td>FirstName :</td>"
				+ "<td><input type='text' name='firstName' value='null'></td></tr>"
				+ "<tr>"
				+ "<td>LastName:</td>"
				+ "<td><input type='text' name='lastName' value='null'></td></tr>"
				+ "<td>City:</td>"
				+ "<td><input type='text' name='city' value='null'></td></tr>"
				+ "<td>State:</td>"
				+ "<td><input type='text' name='state' value='null'></td></tr>"
				+ "<tr><td>Mobile Number     :</td>"
				+ "<td><input type='tel' name='mobileNumber' value='null'></td></tr>"
				+ "<tr><td>EmailId          :</td>"
				+ "<td><input type='email' name='emailId' value='null'></td></tr>"
			
				+ " </form></body></html>");
		*/
