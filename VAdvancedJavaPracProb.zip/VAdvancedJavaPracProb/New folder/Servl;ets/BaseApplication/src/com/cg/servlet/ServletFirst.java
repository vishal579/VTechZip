package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.mbeans.UserMBean;

@WebServlet("/ServletFirst")
public class ServletFirst extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
  

	public void init(ServletConfig config) throws ServletException {
		
	}

	
	public void destroy() {
		
	}

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		PrintWriter writer=response.getWriter();
		writer.print("<html>");
		writer.print("	<head>");
		writer.print("<title>The First Servlet</title></head>");
		writer.print("<body><h2>First Page</h2> <form action='ServletSecond' method='post'> <table><tr><td>FirstName :</td><td><input type='text' name='firstName'></td></tr><tr><td>LastName         :</td><td><input type='text' name='lastName'></td></tr><tr ><td><input type='submit' name='submit'></td></tr> </form></body></html>");
		
	}

	


}/*package com.cg.servlet;



public class UserBean {
	private String firstName,lastName,mobileNumber,emailId,state,city;
    public UserBean() {
		
	}
	public UserBean(String firstName, String lastName) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
	}
	public UserBean(String firstName, String lastName, String mobileNumber, String emailId) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobileNumber = mobileNumber;
		this.emailId = emailId;
	}
	public UserBean(String firstName, String lastName, String mobileNumber, String emailId, String state, String city) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobileNumber = mobileNumber;
		this.emailId = emailId;
		this.state = state;
		this.city = city;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
    
}
*/








