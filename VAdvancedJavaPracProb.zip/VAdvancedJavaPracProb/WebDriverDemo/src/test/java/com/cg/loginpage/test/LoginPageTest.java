package com.cg.loginpage.test;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.loginpage.beans.LoginPage;

public class LoginPageTest {
	private static WebDriver driver;
	private static LoginPage loginPage;

	@BeforeClass
	public static void setUpTestEnv(){
		System.setProperty("webdriver.chrome.driver", "D:\\Java FLP-Crossskilling 9-04-18\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
	}
	@AfterClass
	public static void tearDownEnv(){
		driver=null;
	}
	@Before
	public void setUpMockData(){
		driver.get("https://github.com/login");
		loginPage=new LoginPage();
		PageFactory.initElements(driver, loginPage);
	}
	@After
	public void tearDownMockData(){
		driver.get("https://github.com/login");
		loginPage=new LoginPage();
	}
}
