package com.cg.webdriverdemo.main;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebDriverDemoMain {

	public static void main(String[] args) {
		
			System.setProperty("webdriver.chrome.driver", "D:\\Java FLP-Crossskilling 9-04-18\\chromedriver.exe");
			WebDriver driver=new ChromeDriver();
			driver.get("http://www.google.com");
			
			WebElement searchField=driver.findElement(By.id("lst-ib"));
			searchField.sendKeys("google I/O");
			searchField.submit();
			
			WebElement imagesTab=driver.findElement(By.linkText("Images"));
			imagesTab.click();
			WebElement imageElement=driver.findElements(By.xpath("//class[@id='ZjaC2e-U8FH6KM:']")).get(0);
			WebElement image=imageElement.findElements(By.tagName("img")).get(0);
	}

}
