package com.cg.loginpage.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage {
	@FindBy(id="login_field")
	WebElement userName;
	@FindBy(id="password")
	WebElement password;
	@FindBy(id="btn")
	WebElement button;
	public LoginPage() {
	}
	public WebElement getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName.sendKeys(userName);
	}
	public WebElement getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password.sendKeys(password);
	}
	public WebElement getButton() {
		return button;
	}
	public void clickSubmitButton() {
		this.button.submit();
	}
	
}
