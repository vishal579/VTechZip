package com.cg.wrapperclasses.main;

public class MainClass {
	public static void main(String[] args) {
		Integer iob=new Integer(100);
		int num1=iob;
		Integer iob1=num1+100;
		System.out.println(num1+" "+iob.intValue()+" "+100+" "+iob1);
	}
}
