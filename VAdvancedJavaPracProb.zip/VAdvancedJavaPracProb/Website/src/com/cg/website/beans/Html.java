package com.cg.website.beans;

public class Html {

}
