package com.cg.payroll.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetail;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServices;

import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
@Component(value="services")
public class PayrollServicesImpl implements PayrollServices {
	@Autowired
	private PayrollDAOServices daoServices;

	public PayrollServicesImpl() {

	}

	
	@Override
	public int acceptAssociateDetails(String firstName,String lastName,String emailId,String department,String designation,
			String pancard,int yearlyInvestmentUnder80C,double basicSalary,double epf,double companyPf,int accountNumber,
			String bankName,String ifscCode)throws PayrollServicesDownException{
		return daoServices.insertAssociate(new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetail(accountNumber, bankName, ifscCode)));
	}

	@Override
	public double calculateNetSalary(int associateId)throws AssociateDetailsNotFoundException{
		Associate associate=this.getAssociateDetails(associateId);
		double taxAmount=0.0;
		associate.getSalary().setPersonalAllowance(0.3*associate.getSalary().getBasicSalary());
		associate.getSalary().setConveyenceAllowance(0.2*associate.getSalary().getBasicSalary());
		associate.getSalary().setOtherAllowance(0.1*associate.getSalary().getBasicSalary());
		associate.getSalary().setHra(0.25*associate.getSalary().getBasicSalary());
		associate.getSalary().setGratuity(0.5*associate.getSalary().getBasicSalary());
		associate.getSalary().setGrossSalary(associate.getSalary().getPersonalAllowance()+associate.getSalary().getBasicSalary()+associate.getSalary().getConveyenceAllowance()+associate.getSalary().getOtherAllowance()+associate.getSalary().getHra()+associate.getSalary().getCompanyPf());
		double annualSalary=associate.getSalary().getGrossSalary()*12;
		double taxableSalary=annualSalary;
		double nonTaxableSalary=associate.getYearlyInvestmentUnder80C()+(associate.getSalary().getEpf()*12)+(associate.getSalary().getCompanyPf()*12);
		if(nonTaxableSalary>150000)
			nonTaxableSalary=150000;
		if(taxableSalary<=250000){
			taxAmount=0;
		}	
		else if(taxableSalary>250000 && taxableSalary<=500000){
			taxableSalary=taxableSalary-250000-nonTaxableSalary;
			if(taxableSalary<0)
				taxAmount=0;
			else
				taxAmount=taxableSalary*0.1;	
		}
		else if (taxableSalary>500000 && taxableSalary<=1000000){
			double taxSlab2=(500000-250000-nonTaxableSalary)*0.1;
			taxAmount=(taxableSalary-500000)*0.2+taxSlab2;	
		}
		else if (taxableSalary>1000000){
			double taxSlab2=(500000-250000-nonTaxableSalary)*0.1;
			double taxSlab3=(500000)*0.2;
			taxAmount=(taxableSalary-1000000)*0.3+taxSlab3+taxSlab2;	
		}
		associate.getSalary().setMonthlyTax((float)taxAmount/12);
		associate.getSalary().setNetSalary((float)((annualSalary-taxAmount)/12)-associate.getSalary().getCompanyPf()-associate.getSalary().getEpf());
		daoServices.updateAssociate(associate);
		System.out.println(associate);
		return associate.getSalary().getNetSalary();

	}

	@Override
	public Associate getAssociateDetails(int associateId)throws AssociateDetailsNotFoundException{
		Associate associate=daoServices.getAssociate(associateId);
		if(associate==null)throw new AssociateDetailsNotFoundException("Associate Details Not Found"+" "+associateId);
		return associate;
	}

	@Override
	public List<Associate> getAllAssociateDetails(){
		return daoServices.getAssociates();
	}
	public boolean deleteAssociate(int associateId)throws AssociateDetailsNotFoundException{
		if(daoServices.deleteAssociate(associateId)==false)
			throw new AssociateDetailsNotFoundException("Id to be deleted not found");
		return true;
	}
	

}






/*public boolean updateAssociate(int associateId){

	return daoServices.updateAssociate(this.getAssociateDetails(associateId));
}*/