package com.cg.project.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.UserBean;

@WebServlet("/VHelloServlet")
public class VHelloServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection conn;
	public void init(){
		ServletContext servletContext=getServletContext();
		conn=(Connection) servletContext.getAttribute("conn");

	}


	public void destroy() {

	}


	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		super.doGet(request	, response);
	}


	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			String userName=request.getParameter("userName");
			String password=request.getParameter("password");
			RequestDispatcher dispatcher;
			UserBean userBean=new UserBean(userName, password);

			PreparedStatement ps=conn.prepareStatement("select password from userdetails where userName=?");

			ps.setString(1, userBean.getUserName());
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				if(userBean.getPassword().equals(rs.getString("password"))){
					dispatcher=request.getRequestDispatcher("SuccessPage.jsp");
					request.setAttribute("userBean", userBean);
					dispatcher.forward(request, response);
				}
				else{
					dispatcher=request.getRequestDispatcher("FailurePage.jsp");
					request.setAttribute("errorMessage", "UserName or Password incorrect please try again later");
					dispatcher.forward(request, response);
				}
			}
			else{
				dispatcher=request.getRequestDispatcher("FailurePage.jsp");
				request.setAttribute("errorMessage", "UserName or Password not found <br/>");
				dispatcher.forward(request, response);
				

			}
		} catch (SQLException e) {

			e.printStackTrace();
		}




	}




}



























/*
public void init(ServletConfig config) throws ServletException {

}


public void destroy() {

}


@Override
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	super.doGet(request	, response);
}


@Override
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	String userName=request.getParameter("userName");
	String password=request.getParameter("password");
	RequestDispatcher dispatcher;
	UserBean userBean=new UserBean(userName, password);
	if(userBean.getUserName().equals("Vishal")&&userBean.getPassword().equals("VishalJSC")){
		dispatcher=request.getRequestDispatcher("SuccessServlet");
		request.setAttribute("userBean", userBean);
		dispatcher.forward(request, response);
	}
	else{
		dispatcher=request.getRequestDispatcher("FailureServlet");
		request.setAttribute("errorMessage", "UserName or Password incorrect please try again later");
		dispatcher.forward(request, response);
	}

}*/

