package com.cg.project.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.UserBean;


@WebServlet("/RegistrationFormServlet")
public class RegistrationFormServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection conn;
	public void init(){
		ServletContext servletContext=getServletContext();
		conn=(Connection) servletContext.getAttribute("conn");

	}

	
	public void destroy() {
		
	}

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter writer=response.getWriter();
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String gender=request.getParameter("gender");
		String dob=request.getParameter("dob");
		String mobileNumber=request.getParameter("mobileNumber");
		String emailId=request.getParameter("emailId");
		String state=request.getParameter("state");
		String qualification=request.getParameter("qualification");
		String userName=request.getParameter("userName");
		String password=request.getParameter("password");
		String rePassword=request.getParameter("rePassword");
		String address=request.getParameter("address");
		String []document=request.getParameterValues("document");
		ArrayList<String> documents=new ArrayList<>();
		if(document!=null){
		for(String a:document)
			documents.add(a);
		}
			
		RequestDispatcher dispatcher;
		
	
		if(password.equals(rePassword)){
			UserBean userBean=new UserBean(firstName, lastName, gender, dob, mobileNumber, emailId, state, qualification, userName, rePassword, address, documents);
			try {
				PreparedStatement ins=conn.prepareStatement("insert into userdetails(firstName, lastName, gender, dob, mobileNumber, emailId, state, qualification, userName, rePassword, address, documents)");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else{
			
		}
		
	}

}













/*protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter writer=response.getWriter();
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String gender=request.getParameter("gender");
		String dob=request.getParameter("dob");
		String mobileNumber=request.getParameter("mobileNumber");
		String emailId=request.getParameter("emailId");
		String state=request.getParameter("state");
		String qualification=request.getParameter("qualification");
		String userName=request.getParameter("userName");
		String password=request.getParameter("password");
		String rePassword=request.getParameter("rePassword");
		String address=request.getParameter("address");
		String []documents=request.getParameterValues("document");
		String document="";
		for(String a:documents)
			document+=a;
		String resume=request.getParameter("resume");	
		//@SuppressWarnings("deprecation")
		//String path=request.getRealPath(resume);
		writer.println("<html>");
		writer.println("<head><title>VwebApp</title></head>");
		writer.println("<body><div><a href='Index.html'>Hello VHelloServlet</a></div><div>"+firstName +" " +lastName+" "+gender+" "+dob+" "+emailId+" "+state+" "+qualification+" "+rePassword+" "+address+" "+document+" "+userName+" " +password +" "+resume+"</div></body></html>");
		
	}*/