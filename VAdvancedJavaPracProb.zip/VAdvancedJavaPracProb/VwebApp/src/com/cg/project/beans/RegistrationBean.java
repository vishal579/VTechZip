package com.cg.project.beans;

public class RegistrationBean {

}
