package com.cg.project.listeners;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
@WebListener
public class ProjectListener implements ServletContextListener{
	private Connection conn;
	@Override
	public void contextDestroyed(ServletContextEvent event) {
		try {
			conn.close();
			conn=null;
		} catch (SQLException e) {

			e.printStackTrace();
		}


	}

	@Override
	public void contextInitialized(ServletContextEvent event) {

		try {
			System.out.println(2);
			ServletContext servletContext=event.getServletContext();
			String user=servletContext.getInitParameter("user");
			System.out.println(user);
			String url=servletContext.getInitParameter("url");
			System.out.println(url);
			String driver=servletContext.getInitParameter("driver");
			
			
			Class.forName(driver);

			conn=DriverManager.getConnection(url, user, "");

			servletContext.setAttribute("conn", conn);
		} catch (ClassNotFoundException | SQLException e) {

			e.printStackTrace();
		}

	}

}
