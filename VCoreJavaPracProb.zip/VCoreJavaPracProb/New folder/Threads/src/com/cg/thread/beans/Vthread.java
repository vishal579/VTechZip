package com.cg.thread.beans;

public class Vthread extends Thread{

	public Vthread() {
		super();
	}

	public Vthread(String name) {
		super(name);
	}

	@Override
	public void run() {
		if (this.getName().equals("thread-1")) 
			for(int i=1;i<100;i++){
				if(i%2!=0)
				System.out.println(i);
			}
		else if(this.getName().equals("thread-2"))
			for(int i=1;i<100;i++)
				System.out.print(i);
	}

}
