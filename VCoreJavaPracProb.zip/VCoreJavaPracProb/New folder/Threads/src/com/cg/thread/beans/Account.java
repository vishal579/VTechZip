package com.cg.thread.beans;

public class Account {
	private static int SUCCESS,FAIL=0;
	private volatile int balance;
	public Account() {

	}
	public Account(int balance) {
		super();
		this.balance = balance;
	}
	public static int getSUCCESS() {
		return SUCCESS;
	}
	public static void setSUCCESS(int sUCCESS) {
		SUCCESS = sUCCESS;
	}
	public static int getFAIL() {
		return FAIL;
	}
	public static void setFAIL(int fAIL) {
		FAIL = fAIL;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public synchronized int deposit(int amount){
		balance=balance+amount;
		this.notify();
		return balance;

	}
	public synchronized int  withdraw(int amount) throws InterruptedException{
		if(balance<0||getBalance()-amount<0){
			
			System.out.println("      withdraw fail      "+balance);
			this.wait(2000);
			return balance;
		}	
		else{
			balance=balance-amount;
			System.out.println("       withdraw successful      ");
			return balance;
		}
	}
	@Override
	public String toString() {
		return "Account [balance=" + balance + "]";
	}

}
/*public int deposit(int amount){
		synchronized (this) {
			balance=balance+amount;
			return balance;
		}
	}
	public int  withdraw(int amount){
		synchronized (this) {
			balance=balance-amount;
			return balance;
		}
	}*/