package com.cg.thread.main;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import com.cg.thread.beans.Customer;
import com.cg.thread.beans.RunnableResource;
import com.cg.thread.beans.Vthread;

public class MainClass {

	public static void main(String[] args) throws IOException {
	/*	Thread thread1=new Vthread("thread-1");
		Thread thread2=new Vthread("thread-2");
		thread1.start();
		thread2.start();*/
		//RunnableResource resource=new RunnableResource();
		/*Thread th1=new Thread(new Customer(), "rahul");
		Thread th2=new Thread(new Customer(), "anil");
		Thread th3=new Thread(new Customer(), "satish");
		th1.start();
		th2.start();
		th3.start();*/
		File file=new File("D:\\New Text Document.txt");
		FileInputStream fileInputStream=new FileInputStream(file);
		Properties properties=new Properties();
		properties.load(fileInputStream);
		System.out.println(properties.getProperty("vishal"));
	}
}
