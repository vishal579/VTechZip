package com.cg.thread.beans;

public class RunnableResource implements Runnable{
	Thread t=Thread.currentThread();
	@Override
	public void run() {
		Thread t=Thread.currentThread();
		if (t.getName().equals("thread-0")) 
			for(int i=1;i<100;i++){
				if(i%2!=0)
				System.out.println(i);
			}
		else if(t.getName().equals("thread-1"))
			for(int i=1;i<100;i++)
				System.out.println(i);
	}
}


