package com.cg.inheritance.beans;

public final class SalesManager extends PEmployee {
	private int salesAmount,commission;
	public SalesManager() {
	
	}
	public SalesManager(int employeeId, int basicSalary, String firstName, String lastName, int salesAmount) {
		super(employeeId, basicSalary, firstName, lastName);
		this.salesAmount = salesAmount;
	}
	public SalesManager(int employeeId, int basicSalary, String firstName, String lastName) {
		super(employeeId, basicSalary, firstName, lastName);
	}
	public int getSalesAmount() {
		return salesAmount;
	}
	public void setSalesAmount(int salesAmount) {
		this.salesAmount = salesAmount;
	}
	public int getCommission() {
		return commission;
	}
	public void setCommission(int commission) {
		this.commission = commission;
	}
	public void doSales(){
		System.out.println("Sales Done");
	}
	public void calculateSalary(){
		super.calculateSalary();
		commission=this.salesAmount*20/100;
		this.setTotalSalary(commission+this.getTotalSalary());
	}
	@Override
	public String toString() {
		return "SalesManager [salesAmount=" + salesAmount + ", commission=" + commission + ", getEmployeeId()="
				+ getEmployeeId() + ", getBasicSalary()=" + getBasicSalary() + ", getTotalSalary()=" + getTotalSalary()
				+ ", getFirstName()=" + getFirstName() + ", getLastName()=" + getLastName() + "]";
	}
	
	
}
