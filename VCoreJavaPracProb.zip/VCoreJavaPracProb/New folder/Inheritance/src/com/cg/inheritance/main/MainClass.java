package com.cg.inheritance.main;

import com.cg.inheritance.beans.CEmployee;
import com.cg.inheritance.beans.Employee;
import com.cg.inheritance.beans.PEmployee;
import com.cg.inheritance.beans.SalesManager;
import com.cg.inheritance.beans.Developer;
import com.cg.inheritance.beans.CEmployee;
public class MainClass {
	public static void main(String[] args) {
	//  Employee employee=new Employee(7, 50000, "Vishal", "J",9);
    	Employee employee=new Developer(8,80000, "Vishal", "Sai",8);
		employee.calculateSalary();
		Developer dev=(Developer) employee;
		
		System.out.println(employee.toString()+" "+dev.getIncentive());

		CEmployee cEmployee=new CEmployee(8,  "Vishal", "JSC",8);
		cEmployee.contractSign();
		cEmployee.calculateSalary();
		System.out.println(cEmployee.toString());
		
		SalesManager salesManager=new SalesManager(9, 70000, "Vishal", "Sai",10000);
		salesManager.calculateSalary();
		System.out.println(salesManager.toString());
		salesManager.doSales();
		Developer developer=new Developer(8,80000, "Vishal", "Sai",10);
		developer.calculateSalary();
		System.out.println(	developer.toString());
	}
}
