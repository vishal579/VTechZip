package com.cg.inheritance.beans;

public class PEmployee extends Employee{
	private int hra,da,pa;
	public PEmployee() {
		super();
	}
	
	public PEmployee(int employeeId, int basicSalary, String firstName, String lastName) {
		super(employeeId, basicSalary, firstName, lastName);
	
	}

	public PEmployee(int employeeId, int basicSalary, String firstName, String lastName, int hra, int da, int pa) {
		super(employeeId, basicSalary, firstName, lastName);
		this.hra = hra;
		this.da = da;
		this.pa = pa;
	}

	public int getHra() {
		return hra;
	}
	public void setHra(int hra) {
		this.hra = hra;
	}
	public int getDa() {
		return da;
	}
	public void setDa(int da) {
		this.da = da;
	}
	public int getPa() {
		return pa;
	}
	public void setPa(int pa) {
		this.pa = pa;
	} 
	public void calculateSalary(){
		this.da=this.getBasicSalary()*10/100;
		this.hra=this.getBasicSalary()*5/100;
		this.pa=this.getBasicSalary()*8/100;
		this.setTotalSalary(this.getBasicSalary()+da+pa+hra);
	}

	@Override
	public String toString() {
		return "PEmployee [hra=" + hra + ", da=" + da + ", pa=" + pa + ", getEmployeeId()=" + getEmployeeId()
				+ ", getBasicSalary()=" + getBasicSalary() + ", getTotalSalary()=" + getTotalSalary()
				+ ", getFirstName()=" + getFirstName() + ", getLastName()=" + getLastName() + "]";
	}
	
}
