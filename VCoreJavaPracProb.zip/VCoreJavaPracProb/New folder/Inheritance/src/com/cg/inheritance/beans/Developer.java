package com.cg.inheritance.beans;

public final class Developer extends PEmployee{
	private int noOfProjects,incentive;
	public Developer() {
	}
	public Developer(int employeeId, int basicSalary, String firstName, String lastName) {
		super(employeeId, basicSalary, firstName, lastName);
	}
	public Developer(int employeeId, int basicSalary, String firstName, String lastName, int noOfProjects) {
		super(employeeId, basicSalary, firstName, lastName);
		this.noOfProjects = noOfProjects;
	}
	public int getNoOfProjects() {
		return noOfProjects;
	}
	public void setNoOfProjects(int noOfProjects) {
		this.noOfProjects = noOfProjects;
	}
	public int getIncentive() {
		return incentive;
	}
	public void setIncentive(int incentive) {
		this.incentive = incentive;
	}
	
	public void calculateSalary(){
		super.calculateSalary();
		this.incentive=this.noOfProjects*80000;
		this.setTotalSalary(incentive+this.getTotalSalary());
	}
	
	@Override
	public String toString() {
		return super.toString()+"Developer [noOfProjects=" + noOfProjects + ", incentive=" + incentive + "]";
	}
}
