package com.cg.leavemanagemetystem.beans;

public class ApplyLeaves {
	private int noOfLeavesApplied;
	private String reasonOfLeave,leaveStatus,fromDate,toDate;
	public ApplyLeaves(int noOfLeavesApplied, String reasonOfLeave,
			String leaveStatus, String fromDate, String toDate) {
		super();
		this.noOfLeavesApplied = noOfLeavesApplied;
		this.reasonOfLeave = reasonOfLeave;
		this.leaveStatus = leaveStatus;
		this.fromDate = fromDate;
		this.toDate = toDate;
	}
	public int getNoOfLeavesApplied() {
		return noOfLeavesApplied;
	}
	public void setNoOfLeavesApplied(int noOfLeavesApplied) {
		this.noOfLeavesApplied = noOfLeavesApplied;
	}
	public String getReasonOfLeave() {
		return reasonOfLeave;
	}
	public void setReasonOfLeave(String reasonOfLeave) {
		this.reasonOfLeave = reasonOfLeave;
	}
	public String getLeaveStatus() {
		return leaveStatus;
	}
	public void setLeaveStatus(String leaveStatus) {
		this.leaveStatus = leaveStatus;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	
}
