package com.cg.leavemanagemetystem.main;

import com.cg.leavemanagemetystem.beans.ApplyLeaves;
import com.cg.leavemanagemetystem.beans.Employee;
import com.cg.leavemanagemetystem.beans.LeaveCancellation;
import com.cg.leavemanagemetystem.beans.Leaves;
import com.cg.leavemanagemetystem.beans.TypeOfLeave;

public class MainClass {
	public static void main(String[] args) {
		Employee emplyee = new Employee(121,"pavan");
		ApplyLeaves	applyleaves = new ApplyLeaves(10,"BrothersMarriage","Pending","21/10/2018","31/10/2018");
		LeaveCancellation leavecancellation = new LeaveCancellation("Not permitted", "Sucess");
		Leaves leaves = new Leaves(2, 10, 2, 8);
		TypeOfLeave typeofleave = new TypeOfLeave("Previliged", 5, 2, 2);
		System.out.println(leaves.getAvaLeaves()+" "+typeofleave.getLeaveType());
	}

}
