package com.cg.banking.utility;

import java.io.Serializable;

public class BankingUtilityCookies implements Serializable{
	private int customer_Id_Counter,transaction_Id_Counter;
	private long account_Id_Counter;
	public BankingUtilityCookies(int customer_Id_Counter, int transaction_Id_Counter, long account_Id_Counter) {
		super();
		this.customer_Id_Counter = customer_Id_Counter;
		this.transaction_Id_Counter = transaction_Id_Counter;
		this.account_Id_Counter = account_Id_Counter;
	}
	public int getCustomer_Id_Counter() {
		return customer_Id_Counter;
	}
	public int getTransaction_Id_Counter() {
		return transaction_Id_Counter;
	}
	public long getAccount_Id_Counter() {
		return account_Id_Counter;
	}
	@Override
	public String toString() {
		return "BankingUtilityCookies [customer_Id_Counter=" + customer_Id_Counter + ", transaction_Id_Counter="
				+ transaction_Id_Counter + ", account_Id_Counter=" + account_Id_Counter + "]";
	}
	
}
