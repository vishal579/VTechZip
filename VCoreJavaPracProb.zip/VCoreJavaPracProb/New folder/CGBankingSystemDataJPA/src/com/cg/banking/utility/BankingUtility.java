package com.cg.banking.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Random;

import com.cg.banking.exceptions.BankingServicesDownException;


//import com.mysql.jdbc.Connection;

public class BankingUtility {
	private static Connection conn=null;
	public static Connection getDBConnection() throws BankingServicesDownException{
		try {
			if(conn==null){
				Properties properties=new Properties();
				properties.load(new FileInputStream(new File(".\\resource\\BankingProperties.properties")));
				Class.forName(properties.getProperty("driver"));
				conn=DriverManager.getConnection(properties.getProperty("url"), properties.getProperty("user"),"");
			}
			return conn;
		} catch (ClassNotFoundException | IOException | SQLException e) {
			//e.printStackTrace();
			throw new BankingServicesDownException("Banking services are down",e);
		}
	}
	
}














/*	public static int CUSTOMER_ID_COUNTER=1;
public static long ACCOUNT_NO_COUNTER=8000001;
public static int TRANSACTION_ID_COUNTER=1001;
public static Random random=new Random();*/