package com.cg.basicseleniumexample.main;

public class WebDriverDemo {
	public static void main(String[] args){
		try{
			System.setProperty("webdriver.chrome.driver", "D:\\Java FLP-Crossskilling 9-04-18");
			WebDrive
		}
	}

}
