package com.cg.payroll.daoservices;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.payroll.beans.Associate;

public class PayrollDAOServicesImpl implements PayrollDAOServices {
	public static HashMap<Integer, Associate> associateList=new HashMap<>(); 
	//private static Associate[] associateList=new Associate[10];
	public static int ASSOCIATE_ID_COUNTER=111;
	//private static int ASSOCIATE_IDX_COUNTER=0;
	@Override
	public int insertAssociate(Associate associate) {
		associateList.put(ASSOCIATE_ID_COUNTER, associate);
		associate.setAssociateId(ASSOCIATE_ID_COUNTER++);
		return associate.getAssociateId();
	}
	@Override
	public boolean updateAssociate(Associate associate) {
		if(associateList.replace(associate.getAssociateId(), associate)!=null)
			return true;
		return false;
	}
	@Override
	public boolean deleteAssociate(int associateId) {
		if(getAssociate(associateId)!=null){
			associateList.remove(associateId);
			return true;
		}
		return false;
	}
	@Override
	public Associate getAssociate(int associateId) {
		
		return associateList.get(associateId);
	}
	@Override
	public List<Associate> getAssociates() {
		
		return new ArrayList(associateList.values());
	}
	
}

