package com.cg.payroll.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetail;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class PayrollServicesTest {
	private static PayrollServices services;
	@BeforeClass
	public static void setUpTestEnv(){
		services=new PayrollServicesImpl();
	}
	@AfterClass
	public static void tearDownEnv(){
		services=null;
	}
	@Before
	public void setUpMockData(){
		Associate associate1=new Associate(111, 150000, "V", "J", "IT", "ANALYST", "ABC1", "ABC@GMAIL.COM", new Salary(300000, 1000,1000),new BankDetail(1000, "sbi", "sbin001"));
		Associate associate2=new Associate(112, 120000, "V", "JSC", "IT", "ANALYST", "ABC2", "ABC@GMAIL.COM", new Salary(15000, 1000,1000),new BankDetail(1000, "sbi", "sbin002"));
		
	PayrollDAOServicesImpl.associateList.put(PayrollDAOServicesImpl.ASSOCIATE_ID_COUNTER++, associate1);	
	PayrollDAOServicesImpl.associateList.put(PayrollDAOServicesImpl.ASSOCIATE_ID_COUNTER++, associate2);
	}
	@Test			
	public void acceptAssociateDetailsForValidData() throws PayrollServicesDownException {
		assertEquals(113,services.acceptAssociateDetails("Vishal", "J", "abc@gmail.com", "IT", "Analyst", "abc1000", 150000, 300000, 1000, 1000, 2456789, "sc", "sc2002"));
	}
	@Test			
	public void acceptAssociateDetailsForInValidData() throws PayrollServicesDownException {
		assertNotEquals(112,services.acceptAssociateDetails("Vishal", "J", "abc@gmail.com", "IT", "Analyst", "abc1000", 150000, 300000, 1000, 1000, 2456789, "sc", "sc2002"));
	}
	@Test
	public void testAssociateDetailsForValidData() throws AssociateDetailsNotFoundException{
		assertEquals(new Associate(112, 120000, "V", "JSC", "IT", "ANALYST", "ABC2", "ABC@GMAIL.COM", new Salary(15000, 1000,1000),new BankDetail(1000, "sbi", "sbin002")),services.getAssociateDetails(112));
	}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testAssociateDetailsForInValidData() throws AssociateDetailsNotFoundException{
		assertEquals(new Associate(112, 120000, "V", "JSC", "IT", "ANALYST", "ABC2", "ABC@GMAIL.COM", new Salary(15000, 1000,1000),new BankDetail(1000, "sbi", "sbin002")),services.getAssociateDetails(99));
	}
	@Test
	public void testDeleteAssociate() throws AssociateDetailsNotFoundException{
		assertTrue(services.deleteAssociate(111));
	}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testDeleteAssociateInValidData() throws AssociateDetailsNotFoundException{
		assertFalse(services.deleteAssociate(1111));
	}
	@Test
	public void testNetSalaryInValidData() throws AssociateDetailsNotFoundException{
		assertNotEquals(0,services.calculateNetSalary(111));
	}
	@Test
	public void testNetSalaryValidData() throws AssociateDetailsNotFoundException{
		assertEquals(403033.34375,services.calculateNetSalary(111),1);
		
	}
	@After
	public void tearDownMockData(){
		PayrollDAOServicesImpl.ASSOCIATE_ID_COUNTER=111;
	}
	
	}
