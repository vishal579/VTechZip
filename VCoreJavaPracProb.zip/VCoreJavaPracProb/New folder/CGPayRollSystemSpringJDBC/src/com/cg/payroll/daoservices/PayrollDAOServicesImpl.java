package com.cg.payroll.daoservices;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.cg.payroll.beans.Associate;
@Component(value="daoServices")
public class PayrollDAOServicesImpl implements PayrollDAOServices{
	@Autowired
	private JdbcTemplate jdbcTemplate;
	public PayrollDAOServicesImpl() {
		// TODO Auto-generated constructor stub
	}



	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public int insertAssociate(Associate associate) {
		jdbcTemplate.update("insert into associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId) values (150000,'Vishal', 'J', 'IT', 'Analyst', 'abc1000', 'abc@gmail.com')");
		int associateId=jdbcTemplate.queryForObject("select max(associateId) from associate", Integer.class);
		jdbcTemplate.update("insert into salary values (associateId,300000, 1000, 1000, 2456789)");
		jdbcTemplate.update("insert into bankdetail values (associateId,'sc', 'sc2002')");	
		
		return associateId;
	}
	
	        
	@Override
	public boolean updateAssociate(Associate associate) {
		// TODO Auto-generated method stub
		return false;
	}/*
	private void getUser(){
		String sql = "select * from users";
		try{
			List list = jdbcTemplate.query(sql, new UserMapper());
			System.out.println("Total Records "+ list.size());
		}catch(DataAccessException e){
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		JDBCDao dao = (JDBCDao)context.getBean("jdbcDao");
		dao.getUser();
		dao.insertUser();
	}


	
}
class UserMapper implements RowMapper{

	@Override
	public User mapRow(ResultSet rs, int arg1) throws SQLException {

		User user = new User();
		user.setFirstName(rs.getString("firstName"));
		user.setLastName(rs.getString("lastName"));
		return user;
	}

}*/
@Override
public boolean deleteAssociate(int associateId) {
	// TODO Auto-generated method stub
	return false;
}

@Override
public Associate getAssociate(int associateId) {
	// TODO Auto-generated method stub
	return null;
}

/*@Override
	public List<Map<String, Object>> getAssociates() {
		return this.jdbcTemplate.queryForList("select * from mytable");
		//return null;
	}*/
@Override
public List<Associate> getAssociates() {
	return null;
}

}
