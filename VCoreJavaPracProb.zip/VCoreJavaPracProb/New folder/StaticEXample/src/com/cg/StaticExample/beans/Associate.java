package com.cg.StaticExample.beans;

public class Associate {
	public static String Name_Play;
	
}
