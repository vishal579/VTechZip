package com.cg.StaticExample.main;

import com.cg.StaticExample.beans.Associate;

public class MainClass {

	public static void main(String[] args) {
		System.out.println(Associate.Name_Play);
		Associate associate1=new Associate();
		Associate associate2=new Associate();
		Associate associate3= null;
		associate1.Name_Play="Vishal";
		System.out.println(Associate.Name_Play);	
		associate1.Name_Play="Sai";
		System.out.println(associate1.Name_Play);
		System.out.println(associate3.Name_Play);
	}

}
