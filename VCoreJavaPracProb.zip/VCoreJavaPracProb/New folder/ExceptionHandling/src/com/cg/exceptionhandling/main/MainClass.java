package com.cg.exceptionhandling.main;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		try {
			Scanner scanner=new Scanner(System.in);
			System.out.println("Enter name");
			int a=scanner.nextInt();
			System.out.println("Enter name");
			int b=scanner.nextInt();
			System.out.println(a/b);
			
		}catch (ArithmeticException e) {
			System.out.println("Arithmetic Exception"+e.getMessage());
			e.printStackTrace();
		} 
		catch (Exception e) {
			System.out.println("Generic exception block"+e.getMessage());
			e.printStackTrace();
		}
		System.out.println("a");
	}

}
