package com.cg.banking.exceptions;

//@SuppressWarnings("serial")
public class InvalidAccountTypeException extends Exception{

	public InvalidAccountTypeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidAccountTypeException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidAccountTypeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidAccountTypeException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
