package com.cg.payroll.main;
import com.cg.payroll.services.PayrollServices;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


import com.cg.payroll.beans.*;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {
	public static void main(String[] args)throws AssociateDetailsNotFoundException,PayrollServicesDownException{
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("projectbeans.xml");
		PayrollServices services=(PayrollServices) applicationContext.getBean("services");
//		services.acceptAssociateDetails("Vishal", "J", "abc@gmail.com", "IT", "Analyst", "abc1000", 150000, 300000, 1000, 1000, 2456789, "sc", "sc2002");
//		services.acceptAssociateDetails("Vishal", "JSC", "abc123@gmail.com", "IT", "Analyst", "abc1000", 150000, 300000, 1000, 1000, 2456789, "sc", "sc2002");
//		services.calculateNetSalary(1);	
//		
//		System.out.println(services.deleteAssociate(2));
//		System.out.println(services.getAssociateDetails(1));
//		System.out.println(services.getAllAssociateDetails());
//			//System.out.println(services);
			
	}
}





































/*try{
		PayrollServices payrollServices =new PayrollServicesImpl();
		int associateId1=payrollServices.acceptAssociateDetails("Vishal", "J", "abc@gmail.com", "IT", "Analyst", "abc1000", 150000, 300000, 1000, 1000, 2456789, "sc", "sc2002");
		payrollServices.calculateNetSalary(associateId1);
		System.out.println(payrollServices.getAssociateDetails(associateId1).getAssociateId()+" "+payrollServices.getAssociateDetails(associateId1).getFirstName() + " " +payrollServices.getAssociateDetails(associateId1).getSalary().getGrossSalary()+" "+payrollServices.getAssociateDetails(associateId1).getSalary().getNetSalary()+" "+payrollServices.getAssociateDetails(associateId1).getSalary().getMonthlyTax());


		int associateId2=payrollServices.acceptAssociateDetails("VishalJS", "J", "def@gmail.com", "IT", "Analyst", "abc1000", 150000, 100000, 1000, 1000, 2456789, "sc", "sc2002");
		payrollServices.calculateNetSalary(associateId2);
		System.out.println(payrollServices.getAssociateDetails(associateId2).getAssociateId()+" "+payrollServices.getAssociateDetails(associateId2).getFirstName() + " " +payrollServices.getAssociateDetails(associateId2).getSalary().getGrossSalary()+" "+payrollServices.getAssociateDetails(associateId2).getSalary().getNetSalary()+" "+payrollServices.getAssociateDetails(associateId2).getSalary().getMonthlyTax());

		int associateId3=payrollServices.acceptAssociateDetails("VishalJSC", "J", "abc@gmail.com", "IT", "Analyst", "abc1000", 150000, 150000, 1000, 1000, 2456789, "sc", "sc2002");
		payrollServices.calculateNetSalary(associateId3);
		System.out.println(payrollServices.getAssociateDetails(associateId3).getAssociateId()+" "+payrollServices.getAssociateDetails(associateId3).getFirstName() + " " +payrollServices.getAssociateDetails(associateId3).getSalary().getGrossSalary()+" "+payrollServices.getAssociateDetails(associateId3).getSalary().getNetSalary()+" "+payrollServices.getAssociateDetails(associateId3).getSalary().getMonthlyTax());

		System.out.println(payrollServices.deleteAssociate(112));
		//System.out.println(payrollServices.deleteAssociate(112));
		int associateId4=payrollServices.acceptAssociateDetails("VishalJSC", "J", "abc@gmail.com", "IT", "Analyst", "abc1000", 150000, 150000, 1000, 1000, 2456789, "sc", "sc2002");
		payrollServices.calculateNetSalary(associateId4);
		int associateId5=payrollServices.acceptAssociateDetails("VishalJSC", "J", "abc@gmail.com", "IT", "Analyst", "abc1000", 150000, 150000, 1000, 1000, 2456789, "sc", "sc2002");
		payrollServices.calculateNetSalary(associateId5);
		int associateId6=payrollServices.acceptAssociateDetails("VishalJSC", "J", "abc@gmail.com", "IT", "Analyst", "abc1000", 150000, 150000, 1000, 1000, 2456789, "sc", "sc2002");
		payrollServices.calculateNetSalary(associateId6);
		int associateId7=payrollServices.acceptAssociateDetails("VishalJSC", "J", "abc@gmail.com", "IT", "Analyst", "abc1000", 150000, 150000, 1000, 1000, 2456789, "sc", "sc2002");
		payrollServices.calculateNetSalary(associateId7);
		int associateId8=payrollServices.acceptAssociateDetails("VishalJSC", "J", "abc@gmail.com", "IT", "Analyst", "abc1000", 150000, 150000, 1000, 1000, 2456789, "sc", "sc2002");
		payrollServices.calculateNetSalary(associateId8);
		int associateId9=payrollServices.acceptAssociateDetails("VishalJSC", "J", "abc@gmail.com", "IT", "Analyst", "abc1000", 150000, 150000, 1000, 1000, 2456789, "sc", "sc2002");
		payrollServices.calculateNetSalary(associateId9);
		int associateId10=payrollServices.acceptAssociateDetails("VishalJSC", "J", "abc@gmail.com", "IT", "Analyst", "abc1000", 150000, 150000, 1000, 1000, 2456789, "sc", "sc2002");
		payrollServices.calculateNetSalary(associateId10);
		int associateId11=payrollServices.acceptAssociateDetails("VishalJSC", "J", "abc@gmail.com", "IT", "Analyst", "abc1000", 150000, 150000, 1000, 1000, 2456789, "sc", "sc2002");
		payrollServices.calculateNetSalary(associateId11);
		int associateId12=payrollServices.acceptAssociateDetails("VishalJSC", "J", "abc@gmail.com", "IT", "Analyst", "abc1000", 150000, 150000, 1000, 1000, 2456789, "sc", "sc2002");
		payrollServices.calculateNetSalary(associateId12);
		//System.out.println(payrollServices.getAssociateDetails(190));
		
		//List<Associate> associates=payrollServices.getAllAssociateDetails();
		//System.out.println(associates[0].toString()+" "+associates[1].toString()+" "+associates[10].toString());
		
		}
		catch (AssociateDetailsNotFoundException e) {
			e.printStackTrace();
		}
		catch(PayrollServicesDownException e){
			e.printStackTrace();
		}
		
		
		
		
		*/


/*String departmentToBeSearch="IT";
int investmentToBeSearched=100;
Associate associate=searchAssociate(departmentToBeSearch,investmentToBeSearched);
if(associate!=null)
System.out.println(associate.getAssociateId()+" "+associate.getFirstName()+" "+associate.getSalary().getBasicSalary());
else
System.out.println("Not Found");	
}
public static Associate searchAssociate(String department,int investmentToBeSearched){
Associate[] associates=new Associate[3];
associates[0]=new Associate(100, 1000, "Vishal", "Sai", "IT", "Analyst", "ab10000", "abc@gmail.com",new Salary(20000, 12, 12, 3000, 2000, 12, 10, 10, 8, 26000, 24000));
//associates[1]=new Associate(200, 1234, "JVS", "C", "IT", "Software engg", "bg1234", "def@gmail.com");
for (Associate associate : associates) {
	if(associate!=null && associate.getDepartment()==department && associate.getYearlyInvestmentUnder80C()>=investmentToBeSearched&&associate.getSalary().getBasicSalary()>15000)
		return associate;
}
return null;
}*/