package com.cg.IOProgramming.beans;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SerializationExample {
	

	public Object doDeSerialization(File fromFile) throws IOException, ClassNotFoundException {
		try(ObjectInputStream src=new ObjectInputStream(new FileInputStream(fromFile))){
			return src.readObject();
		}
	}

	public void doSerialization(File fromFile) throws FileNotFoundException, IOException {
		Associate associate=new Associate(1, 0, "v"	,"j","it", "a","abc", "abc@gmail.com");
		try(ObjectOutputStream dest=new ObjectOutputStream(new FileOutputStream(fromFile))){
			dest.writeObject(associate);
		}
		System.out.println(associate+" "+fromFile.getAbsolutePath());
		
	}
}
