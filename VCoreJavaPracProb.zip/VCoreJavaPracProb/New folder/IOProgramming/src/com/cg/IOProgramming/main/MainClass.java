package com.cg.IOProgramming.main;

import java.io.Console;
import java.io.File;
import java.io.IOException;

import com.cg.IOProgramming.beans.ByteStreamDemo;
import com.cg.IOProgramming.beans.SerializationExample;
import com.cg.IOProgramming.beans.Associate;
public class MainClass {

	public static void main(String[] args) throws ClassNotFoundException {
		try{
		File file=new File("d:\\IOProgramming.txt");
		File file1=new File("d:\\New Text Document.txt");
		ByteStreamDemo byteStreamDemo=new ByteStreamDemo();
		byteStreamDemo.byteReadWriteWork(file1, file);
		if(!(file1.exists()))
			file1.createNewFile();
		SerializationExample example=new SerializationExample();
		example.doSerialization(file1);
		Object obj=example.doDeSerialization(file1);
		System.out.println((Associate)obj+" ");
	/*	System.out.println(file.canRead());
		System.out.println(file.getPath());
		System.out.println(file.getParentFile());
		System.out.println(file.getTotalSpace());
		System.out.println(file.isFile());
		System.out.println(file.length());
		System.out.println(file.getName());
		System.out.println(file.canWrite());
		System.out.println(file.lastModified());*/
			} catch (IOException e) {
				
				e.printStackTrace();
			}

	}

}
