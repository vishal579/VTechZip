package com.cg.IOProgramming.beans;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class ByteStreamDemo {
	public void byteReadWriteWork(File fromFile, File toFile) throws IOException{
		try(BufferedInputStream src=new BufferedInputStream(new FileInputStream(fromFile))){
			try(BufferedOutputStream dest=new BufferedOutputStream(new FileOutputStream(toFile))){
				int data=0;
				//reading file char by char
				while((data=src.read())!=-1){
					dest.write(data);
					//System.out.print((char)data);
				}
				//reading full file
				byte[] dataBuffer=new byte[(int)fromFile.length()]; 
				src.read(dataBuffer);
				//dest.close();
				dest.write(dataBuffer);
				//src.close();
				//System.out.println(dataBuffer);
			}
		}
	}
}
















































/*FileInputStream src=new FileInputStream(fromFile);
		FileOutputStream dest=new FileOutputStream(toFile);
		
		int data=0;
		//reading file char by char
		while((data=src.read())!=-1){
			dest.write(data);
			//System.out.print((char)data);
		}
		//reading full file
		byte[] dataBuffer=new byte[(int)fromFile.length()]; 
		src.read(dataBuffer);
		dest.write(dataBuffer);
		//src.close();
		//System.out.println(dataBuffer);*/