package com.cg.collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.cg.collections.beans.Customer;

public class ListClassDemo {
	//public static void arrayListClassWork(){

	/*ArrayList<String> strList=new ArrayList<>();
	strList.add("Vishal");
	strList.add("Sai");
	strList.add("Chowdary");
	strList.add(0,"Jakkampudi");
	//Collections.sort();
	/*System.out.println(strList.toString());
	Collections.sort(strList);
	System.out.println(strList);
	System.out.println(strList.toString());
	System.out.println(strList.size());
	System.out.println(strList.get(3));
	Iterator<String> iterator=strList.iterator();
	while(iterator.hasNext()){
		System.out.println(iterator.next());
	}
	/*for (Object obj: reverse(strList))
		1 System.out.print(obj + �,�);
		2 }
	print(strList);
	ArrayList<Customer> customerList=new ArrayList<>();
	customerList.add(new Customer(1, "Vishal", "sai"));
	customerList.add(new Customer(3, "Vishu", "JSC"));
	customerList.add(new Customer(2, " J Vishal", "C"));
	customerList.add(new Customer(4, " JS Vishal", "C"));
	//Customer customerToBeSearched=new Customer(2, "Vishu", "JSC");
	Collections.sort(customerList);
	
	//System.out.println(customerList.toString());
	
	/*for(Customer customer:customerList)
		System.out.println(customer);
	customerList.add(new Customer(1, "Vishal", "sai"));
	customerList.add(new Customer(3, "Vishu", "JSC"));
	customerList.add(new Customer(2, " J Vishal", "C"));
	customerList.add(new Customer(4, " JS Vishal", "C"));
	Collections.sort(customerList,new CustomerComparator());
	//System.out.println(customerList.toString());
	print(customerList);
	}
	
	public static void print(ArrayList<?> ref){
		for(Object o:ref)
			System.out.println(o);
	}*/
//}
	public static Iterator reverse(List list) {
		Collections.reverse(list);
		 return list.iterator();
		 }
		 public static void main(String[] args) {
		 List list = new ArrayList();
		 list.add(1); list.add(2); list.add(3);
		// for (Object obj: reverse(list))
		// System.out.print(obj + �,�);
		 }

}
