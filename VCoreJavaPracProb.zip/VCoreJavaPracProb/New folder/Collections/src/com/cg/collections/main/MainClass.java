package com.cg.collections.main;

import com.cg.collections.ListClassDemo;
import com.cg.collections.MyGenericType;
import com.cg.collections.beans.Customer;

public class MainClass {
	public static void main(String[] args) {
		ListClassDemo classDemo=new ListClassDemo();
	//	classDemo.arrayListClassWork();
		
		MyGenericType<Integer> intGenericType=new MyGenericType<Integer>(100, 200);
		MyGenericType<Customer> customerType=new MyGenericType<Customer>(new Customer(), new Customer());
		
	}
}
