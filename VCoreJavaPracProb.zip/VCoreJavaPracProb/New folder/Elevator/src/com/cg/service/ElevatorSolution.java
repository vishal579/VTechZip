package com.cg.service;

public class ElevatorSolution {
	public int solution(int[]A,int[] B,int t_persons,int t_weight,int m)
	{
		int i=0;
		while(i!=A.length){
			int j=0,stops=0;
			int sum_w=0,sum_p=0;
		while(sum_w<=t_weight && sum_p<=t_persons){
			sum_w=sum_w+A[sum_p];
			sum_p++;
			i++;
		}
		i--;
		while(i!=0){
			if(B[i-1]==B[i-2])
				continue;
			else
				stops++;
			i--;
			
		}
	}
		return 0;
	}
}
