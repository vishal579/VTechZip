package com.cg.mobilebilling.main;

import com.cg.mobilebilling.beans.Address;
import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostPaidAccount;

public class MainClass {

	public static void main(String[] args) {
		
		Customer customer=new Customer("Vishal", "Sai", "abc@gmail.com", "abc1000", "1-11-1111", 10001, 8888888888l, 2483000000l,new PostPaidAccount[3],new Address("HYD", "TG", "INDIA", 500001L));
		PostPaidAccount[] postPaidAccounts=customer.getPostPaidAccounts();
		postPaidAccounts[0]=new PostPaidAccount(1111111, new Plan(), new Bill[3]);
		Bill[] bills=customer.getPostPaidAccounts()[0].getBills();
		bills[0]=new Bill(1, 20, 30, 23, 44, 2, 1, 12, 12, 12, 2000, 500, 2, 3);
		System.out.println(customer.getCustomerId()+" "+customer.getAddress().getCity()+" "+customer.getPostPaidAccounts()[0].getBills()[0].getBillID());
	}	
}
