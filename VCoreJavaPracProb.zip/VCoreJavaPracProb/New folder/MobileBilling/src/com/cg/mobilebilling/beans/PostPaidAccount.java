package com.cg.mobilebilling.beans;

public class PostPaidAccount {
	private int mobileNo;
	private Plan plan;
	private Bill[] bills;
	public PostPaidAccount() {
		// TODO Auto-generated constructor stub
	}
	public PostPaidAccount(int mobileNo, Plan plan, Bill[] bills) {
		super();
		this.mobileNo = mobileNo;
		this.plan = plan;
		this.bills = bills;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public Plan getPlan() {
		return plan;
	}
	public void setPlan(Plan plan) {
		this.plan = plan;
	}
	public Bill[] getBills() {
		return bills;
	}
	public void setBills(Bill[] bills) {
		this.bills = bills;
	}
	
}
