package com.cg.services.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.services.beans.InvalidNoRangeException;
import com.cg.services.beans.MathServices;
import com.cg.services.beans.MathServicesImpl;

//import junit.framework.Assert;

public class MathServicesTest {
	private static MathServices services;
	private int validNum1,validNum2,inValidNum1,inValidNum2,expectedAns;
	@BeforeClass
	public static void setUpTestEnv(){
		services=new MathServicesImpl();
	}
	@AfterClass
	public static void cleanEnv(){
		services=null;
	}
	@Before
	public void setUpMockData(){
		validNum1=1;
		validNum2=2;
		inValidNum1=-1;
		inValidNum2=-2;
	}
	@After
	public void tearDownMockData(){
		validNum1=1;
		validNum2=2;
		inValidNum1=-1;
		inValidNum2=-2;
		expectedAns=0;
	}
	@Test(expected=InvalidNoRangeException.class)
	public void testAddFirstInvalidNo() throws InvalidNoRangeException {
		services.add(inValidNum1, validNum2);
	}
	@Test(expected=InvalidNoRangeException.class)
	public void testAddSecondInvalidNo() throws InvalidNoRangeException {
		services.add(validNum1, inValidNum2);
	}
	@Test
	public void testAdd() throws InvalidNoRangeException{
		Assert.assertEquals(3, services.add(validNum1, validNum2));
	}
	@Test(expected=InvalidNoRangeException.class)
	public void testSubFirstInvalidNo() throws InvalidNoRangeException {
		services.sub(inValidNum1, validNum2);
	}
	@Test(expected=InvalidNoRangeException.class)
	public void testSubSecondInvalidNo() throws InvalidNoRangeException {
		services.sub(validNum1, inValidNum2);
	}
	@Test
	public void testSub() throws InvalidNoRangeException{
		Assert.assertEquals(-1, services.sub(validNum1, validNum2));
	}

	@Test(expected=InvalidNoRangeException.class)
	public void testMulFirstInvalidNo() throws InvalidNoRangeException {
		services.mul(inValidNum1, validNum2);
	}
	@Test(expected=InvalidNoRangeException.class)
	public void testMulSecondInvalidNo() throws InvalidNoRangeException {
		services.mul(validNum1, inValidNum2);
	}
	@Test
	public void testMul() throws InvalidNoRangeException{
		Assert.assertEquals(2, services.mul(validNum1, validNum2));
	}

	@Test(expected=InvalidNoRangeException.class)
	public void testDivFirstInvalidNo() throws InvalidNoRangeException {
		services.div(inValidNum1, validNum2);
	}
	@Test(expected=InvalidNoRangeException.class)
	public void testDivSecondInvalidNo() throws InvalidNoRangeException {
		services.div(validNum1, inValidNum2);
	}
	@Test
	public void testDiv() throws InvalidNoRangeException{
		Assert.assertEquals(0, services.div(validNum1, validNum2));
	}


}