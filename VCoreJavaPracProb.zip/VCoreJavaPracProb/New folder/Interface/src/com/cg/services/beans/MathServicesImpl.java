package com.cg.services.beans;

public class MathServicesImpl implements MathServices{
    public MathServicesImpl() {
    	
    }
	@Override
	public int add(int a, int b) throws InvalidNoRangeException {
		if((a<0)||(b<0))
			throw new InvalidNoRangeException();
		return a+b;
	}

	@Override
	public int sub(int a, int b) throws InvalidNoRangeException {
		if((a<0)||(b<0))
			throw new InvalidNoRangeException();
		return a-b;
	}

	@Override
	public int mul(int a, int b) throws InvalidNoRangeException {
		if((a<0)||(b<0))
			throw new InvalidNoRangeException();
		return a*b;
	}

	@Override
	public int div(int a, int b) throws InvalidNoRangeException {
		if((a<0)||(b<=0))
			throw new InvalidNoRangeException();
		return a/b;
	}

}
