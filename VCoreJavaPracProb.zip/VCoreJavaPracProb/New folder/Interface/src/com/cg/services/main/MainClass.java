package com.cg.services.main;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import com.cg.IOProgramming.beans.Associate;
import com.cg.services.beans.MathServices;
import com.cg.services.beans.MathServicesImpl;

public class MainClass {
	public static void main(String[] args) throws ClassNotFoundException, IOException {
		//MathServices mathServices=new MathServicesImpl();
	//	System.out.println(mathServices.add(300,200));
		//System.out.println(mathServices.a);
		File file1=new File("d:\\New Text Document.txt");
		
		
		if(!(file1.exists()))
			file1.createNewFile();
		
		doDeSerialization(file1);
		Object obj=doDeSerialization(file1);
		System.out.println((Associate)obj);
		
	}
	public static Object doDeSerialization(File fromFile) throws IOException, ClassNotFoundException {
		try(ObjectInputStream src=new ObjectInputStream(new FileInputStream(fromFile))){
			return src.readObject();
		}
	}
}
