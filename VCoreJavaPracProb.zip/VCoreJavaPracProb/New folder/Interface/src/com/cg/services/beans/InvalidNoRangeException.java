package com.cg.services.beans;

public class InvalidNoRangeException extends Exception {

	public InvalidNoRangeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidNoRangeException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public InvalidNoRangeException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidNoRangeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidNoRangeException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
}
