package com.cg.banking.daoservices;

//import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

//import org.hibernate.Session;
//import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

//import java.util.Random;
import com.cg.banking.utility.BankingUtility;
import com.cg.banking.utility.BankingUtilityCookies;
//import com.mysql.jdbc.PreparedStatement;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.BankingServicesDownException;
@Component(value="daoServices")
public class BankingDAOServicesImpl implements BankingDAOServices{
	@Autowired
	//private SessionFactory sessionFactory;
	//private Session session;
	private Transaction transaction;
	private static int prevCustomerId;
	private static long prevAccountNo;
	
	public BankingDAOServicesImpl() throws BankingServicesDownException {
		
	}
	
	@Override
	public int insertCustomer(Customer customer) throws SQLException {
		return 0;
	}

	@Override
	public long insertAccount(int customerId, Account account) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Customer getCustomer(int customerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Customer> getCustomers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Account> getAccounts(int customerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {
		// TODO Auto-generated method stub
		return null;
	}

	
}










//BankingUtilityCookies bankingUtilityCookies=(BankingUtilityCookies) src.readObject();
//for(Customer customer:customerList)
//customerMap.put(customer.getCustomerId(), customer);
//BankingUtility.CUSTOMER_ID_COUNTER=customerList.get(customerList.size()-1).getCustomerId()+1;
//BankingUtility.ACCOUNT_NO_COUNTER;

//System.out.println(customerList.size());
//System.out.println(customer.getCustomerId()+" "+customer);
/*(System.out.println(getCustomers().size());
System.out.println(getCustomers().get(0).getAccountMap().size());
System.out.println(getCustomers().get(1).getAccountMap().size());
//System.out.println(getCustomers().size());
 * for(int i=0;i<customerList.size();i++){
					if(!(customer.getAccountMap().isEmpty()))
				}
				BankingUtility.CUSTOMER_ID_COUNTER=customerList.get(customerList.size()-1).getCustomerId()+1;
			System.out.println(BankingUtility.CUSTOMER_ID_COUNTER);
 */
//System.out.println(customer.getAccountMap().size());
//System.out.println(getCustomers().get(getCustomers().size()-1).getAccountMap().size());
//System.out.println(getCustomers().get(0).getAccountMap().size());