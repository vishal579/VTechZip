package com.cg.banking.services;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.*;
@Component(value="services")
public class BankingServicesImpl implements BankingServices {
	
	private BankingDAOServicesImpl daoServicesImpl;
	public BankingServicesImpl() {
		//daoServicesImpl=new BankingDAOServicesImpl();
	}
	
	public BankingDAOServicesImpl getDaoServicesImpl() {
		return daoServicesImpl;
	}

	public void setDaoServicesImpl(BankingDAOServicesImpl daoServicesImpl) {
		this.daoServicesImpl = daoServicesImpl;
	}

	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String emailId, String panCard,
			String localAddressCity, String localAddressState, int localAddressPinCode, String homeAddressCity,
			String homeAddressState, int homeAddressPinCode)throws BankingServicesDownException, SQLException{

		return daoServicesImpl.insertCustomer(new Customer(firstName, lastName, emailId, panCard, new Address(localAddressPinCode, localAddressCity, localAddressState), new Address(homeAddressPinCode, homeAddressCity, homeAddressState)));
	}

	@Override
	public long openAccount(int customerId, String accountType, float initBalance) throws InvalidAmountException,
	CustomerNotFoundException,
	InvalidAccountTypeException,
	BankingServicesDownException, SQLException{
		if(initBalance<0)
			throw new InvalidAmountException("Please enter valid amount >0");
	//	if(daoServicesImpl.getCustomer(customerId)==null)
		//	throw new CustomerNotFoundException("The customerId you entered is not found");
		if(accountType.equalsIgnoreCase("savings")||accountType.equalsIgnoreCase("current")||accountType.equalsIgnoreCase("salary"))
			
			return daoServicesImpl.insertAccount(customerId, new Account(accountType, initBalance));
		else
			throw new InvalidAccountTypeException("Account type is invalid");
	}

	@Override
	public float depositAmount(int customerId, long accountNo, float amount)throws CustomerNotFoundException,
	AccountNotFoundException,BankingServicesDownException, AccountBlockedException, InvalidAmountException {
		if(daoServicesImpl.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("The customerId you entered is not found");

		if(daoServicesImpl.insertTransaction(customerId, accountNo, new Transaction(amount,"Deposit"))==false)
			throw new AccountNotFoundException("Account not found");
		if(daoServicesImpl.getAccount(customerId, accountNo).getStatus()=="Blocked")
			throw new AccountBlockedException("Your account is currently blocked. Please contact with your bank");
		if(amount<0)
			throw new InvalidAmountException("Please enter valid amount >0");
		
		//getAccountAllTransaction(customerId, accountNo)[getAccountDetails(customerId, accountNo).getTransactionIdxCounter()-1].setTransactionType("Deposit");

		this.getAccountDetails(customerId, accountNo).setAccountBalance(this.getAccountDetails(customerId, accountNo).getAccountBalance()+amount);
		return this.getAccountDetails(customerId, accountNo).getAccountBalance();
	}

	@Override
	public float withdrawAmount(int customerId, long accountNo, float amount, int pinNumber)throws InsufficientAmountException,CustomerNotFoundException,
	AccountNotFoundException,InvalidPinNumberException,
	BankingServicesDownException ,AccountBlockedException, InvalidAmountException {
		if(daoServicesImpl.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("The customerId you entered is not found");
		if(getAccountDetails(customerId, accountNo)==null)
			throw new AccountNotFoundException("Account not found");
		if(getAccountDetails(customerId, accountNo).getStatus()=="Blocked")
			throw new AccountBlockedException("Your account is currently blocked. Please contact your Bank");
		if(amount<0)
			throw new InvalidAmountException("Please enter valid amount >0");
		while(getAccountDetails(customerId, accountNo).getPinCounter()<3){

			if(getAccountDetails(customerId, accountNo).getPinNumber()==pinNumber&&getAccountDetails(customerId, accountNo).getAccountBalance()>amount){
				daoServicesImpl.insertTransaction(customerId, accountNo, new Transaction(amount,"Withdraw"));
				this.getAccountDetails(customerId, accountNo).setAccountBalance(this.getAccountDetails(customerId, accountNo).getAccountBalance()-amount);
				getAccountDetails(customerId, accountNo).setPinCounter(0);
				//getAccountAllTransaction(customerId, accountNo)[getAccountDetails(customerId, accountNo).getTransactionIdxCounter()-1].setTransactionType("Withdraw");
				//getAccountDetails(customerId, accountNo).getTransactionMap();
				//System.out.println(this.getAccountDetails(customerId, accountNo).getAccountBalance()+"return amt");
				return this.getAccountDetails(customerId, accountNo).getAccountBalance();
			}
			getAccountDetails(customerId, accountNo).setPinCounter(getAccountDetails(customerId, accountNo).getPinCounter()+1);
			if(	getAccountDetails(customerId, accountNo).getPinCounter()>=3)
				getAccountDetails(customerId, accountNo).setStatus("Blocked");
			if(getAccountDetails(customerId, accountNo).getPinNumber()!=pinNumber)
				throw new InvalidPinNumberException("You entered incorrect pin. Entering wrong pin 3 times will make your account blocked");
			if(getAccountDetails(customerId, accountNo).getAccountBalance()<amount)
				throw new InsufficientAmountException("Your account has insuffcient balance :"+" "+this.getAccountDetails(customerId, accountNo).getAccountBalance());	

		}
		return 0;
	}

	@Override
	public boolean fundTransfer(int customerIdTo, long accountNoTo, int customerIdFrom, long accountNoFrom,
			float transferAmount, int pinNumber) throws InsufficientAmountException,
	CustomerNotFoundException,
	AccountNotFoundException,InvalidPinNumberException,
	BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		if(daoServicesImpl.getCustomer(customerIdTo)==null)
			//return true;
			throw new CustomerNotFoundException();
		if(getAccountDetails(customerIdTo, accountNoTo)==null)
			throw new AccountNotFoundException("Account not found");
		if(transferAmount<0)
			throw new InvalidAmountException("Please enter valid amount >0");
	
		if(withdrawAmount(customerIdFrom, accountNoFrom, transferAmount, pinNumber)==0)
			return false;

			depositAmount(customerIdTo, accountNoTo, transferAmount);
		return true;


	}

	@Override
	public Customer getCustomerDetails(int customerId)throws CustomerNotFoundException,BankingServicesDownException {
		if(daoServicesImpl.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("The customerId you entered is not found");
		return daoServicesImpl.getCustomer(customerId);
	}

	@Override
	public Account getAccountDetails(int customerId, long accountNo)throws 
	CustomerNotFoundException,AccountNotFoundException,BankingServicesDownException {
		if(daoServicesImpl.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("The customerId you entered is not found");
		if(daoServicesImpl.getAccount(customerId, accountNo)==null)
			throw new AccountNotFoundException("Account not found");
		return daoServicesImpl.getAccount(customerId, accountNo);
	}

	@Override
	public int generateNewPin(int customerId, long accountNo)throws
	CustomerNotFoundException,AccountNotFoundException ,
	BankingServicesDownException {
		if(daoServicesImpl.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("The customerId you entered is not found");
		if(daoServicesImpl.getAccount(customerId, accountNo)==null)
			throw new AccountNotFoundException("Account not found");
		return daoServicesImpl.generatePin(customerId, this.getAccountDetails(customerId, accountNo));
	}

	@Override
	public boolean changeAccountPin(int customerId, long accountNo, int oldPinNumber, int newPinNumber)throws CustomerNotFoundException,
	AccountNotFoundException,
	InvalidPinNumberException,BankingServicesDownException {
		if(daoServicesImpl.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("The customerId you entered is not found");
		if(getAccountDetails(customerId, accountNo)==null)
			throw new AccountNotFoundException("Account not found");
		if(getAccountDetails(customerId, accountNo).getPinNumber()==oldPinNumber){
			getAccountDetails(customerId, accountNo).setPinNumber(newPinNumber);
			return true;
		}
		else
			throw new InvalidPinNumberException("You entered incorrect pin");

		//return false;
	}

	@Override
	public List<Customer> getAllCustomerDetails()throws BankingServicesDownException {

		return daoServicesImpl.getCustomers();
	}

	@Override
	public List<Account> getcustomerAllAccountDetails(int customerId)throws BankingServicesDownException,CustomerNotFoundException {

		return daoServicesImpl.getAccounts(customerId);
	}

	@Override
	public List<Transaction> getAccountAllTransaction(int customerId, long accountNo)throws BankingServicesDownException,
	CustomerNotFoundException,
	AccountNotFoundException {
		if(daoServicesImpl.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("The customerId you entered is not found");
		if(getAccountDetails(customerId, accountNo)==null)
			throw new AccountNotFoundException("Account not found");
		return daoServicesImpl.getTransactions(customerId, accountNo);
	}
	@Override
	public String accountStatus(int customerId, long accountNo)throws BankingServicesDownException,
	CustomerNotFoundException,
	AccountNotFoundException, AccountBlockedException {
		if(daoServicesImpl.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("The customerId you entered is not found");
		if(getAccountDetails(customerId, accountNo)==null)
			throw new AccountNotFoundException("Account not found");
		if(getAccountDetails(customerId, accountNo).getStatus()=="Blocked")
			throw new AccountBlockedException("Your account is currently blocked. Please contact your Bank");
		return getAccountDetails(customerId, accountNo).getStatus();
	}
	public boolean deleteAccount(int customerId, long accountNo)throws BankingServicesDownException,
	CustomerNotFoundException,
	AccountNotFoundException{
		if(daoServicesImpl.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("The customerId you entered is not found");
		if(getAccountDetails(customerId, accountNo)==null)
			throw new AccountNotFoundException("Account not found");
		return daoServicesImpl.deleteAccount(customerId, accountNo);
	}
	public void doDeSerialization(File fromFile) throws IOException, ClassNotFoundException {
		if(fromFile.length()==0)
			return;
		//else	
			//System.out.println(fromFile.length());
		//	daoServicesImpl.doDeSerialization(fromFile);
	}

	public  void doSerialization(File fromFile) throws FileNotFoundException, IOException {
		//daoServicesImpl.doSerialization(fromFile);
	}

	

}
