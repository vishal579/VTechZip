package com.cg.eventmanagement.beans;

public class Event {
		private String typeofEvent,eventFromDate,eventToDate;
		private int eventCost,noofDays,noofAttendies;
			
			public Event(String typeofEvent, String eventFromDate,
					String eventToDate, int eventCost, int noofDays,
					int noofAttendies) {
				super();
				this.typeofEvent = typeofEvent;
				this.eventFromDate = eventFromDate;
				this.eventToDate = eventToDate;
				this.eventCost = eventCost;
				this.noofDays = noofDays;
				this.noofAttendies = noofAttendies;
			}
			public String getTypeofEvent() {
				return typeofEvent;
			}
			public void setTypeofEvent(String typeofEvent) {
				this.typeofEvent = typeofEvent;
			}
			public String getEventFromDate() {
				return eventFromDate;
			}
			public void setEventFromDate(String eventFromDate) {
				this.eventFromDate = eventFromDate;
			}
			public String getEventToDate() {
				return eventToDate;
			}
			public void setEventToDate(String eventToDate) {
				this.eventToDate = eventToDate;
			}
			public int getEventCost() {
				return eventCost;
			}
			public void setEventCost(int eventCost) {
				this.eventCost = eventCost;
			}
			public int getNoofDays() {
				return noofDays;
			}
			public void setNoofDays(int noofDays) {
				this.noofDays = noofDays;
			}
			public int getNoofAttendies() {
				return noofAttendies;
			}
			public void setNoofAttendies(int noofAttendies) {
				this.noofAttendies = noofAttendies;
			}
			
}
