package com.cg.eventmanagement.services;

public class EventServicesImpl {

}
