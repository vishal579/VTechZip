package com.cg.eventmanagement.main;

import com.cg.eventmanagement.beans.Catering;
import com.cg.eventmanagement.beans.Customer;
import com.cg.eventmanagement.beans.Event;
import com.cg.eventmanagement.beans.EventAddress;
import com.cg.eventmanagement.beans.Menu;

public class MainClass {

	public static void main(String[] args) {
		Customer customer = new Customer("Mutyala Srivatsava", 8790532425l);
		EventAddress eventAddress = new EventAddress("Hyderabad", "Telangana", "India", 500018);
		Event event = new Event("Marriage", "25th Jan 2018", "1st Feb 2018", 2000000, 7, 2000);
		Catering catering = new Catering("Available", "Food", 1000000);
		Menu menu = new Menu("Veg Biryani", "Available", 150);
			System.out.println(customer.getMobileNo()+" "+eventAddress.getCity()+" "+event.getTypeofEvent()+" "+catering.getCateringStatus()+" "+menu.getNameofItem());
			
	}

}
