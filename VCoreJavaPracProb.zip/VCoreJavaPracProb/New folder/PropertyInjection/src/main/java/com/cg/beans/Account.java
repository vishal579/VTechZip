package com.cg.beans;

import org.springframework.stereotype.Component;

@Component("account")
public class Account {
	public Account(float accountBalance, long accountNo, Address address) {
		super();
		this.accountBalance = accountBalance;
		this.accountNo = accountNo;
		this.address = address;
	}
	private float accountBalance;
	private long accountNo;	
	private Address address;
	public Account() {
		// TODO Auto-generated constructor stub
	}
	public float getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(float accountBalance) {
		this.accountBalance = accountBalance;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Account [accountBalance=" + accountBalance + ", accountNo=" + accountNo + ", address=" + address + "]";
	}
	
}
