package com.cg.payroll.beans;

import javax.persistence.Embeddable;
import javax.persistence.Entity;
//import javax.persistence.Id;
import javax.persistence.Id;

@Embeddable
public class Salary {
	
	private double basicSalary,personalAllowance, epf,companyPf;
	private double hra, conveyenceAllowance, otherAllowance,grossSalary,netSalary,monthlyTax,gratuity;
	public Salary() {
	}
	public Salary(double basicSalary, double personalAllowance, double epf, double companyPf, double hra, double conveyenceAllowance,
			double otherAllowance, double grossSalary, double netSalary, double monthlyTax, double gratuity) {
		super();
		this.basicSalary = basicSalary;
		this.personalAllowance = personalAllowance;
		this.epf = epf;
		this.companyPf = companyPf;
		this.hra = hra;
		this.conveyenceAllowance = conveyenceAllowance;
		this.otherAllowance = otherAllowance;
		this.grossSalary = grossSalary;
		this.netSalary = netSalary;
		this.monthlyTax = monthlyTax;
		this.gratuity = gratuity;
	}

	public Salary(double basicSalary, double epf, double companyPf) {
		super();
		this.basicSalary = basicSalary;
		this.epf = epf;
		this.companyPf = companyPf;
	}


	public double getBasicSalary() {
		return basicSalary;
	}


	public void setBasicSalary(double basicSalary) {
		this.basicSalary = basicSalary;
	}


	public double getPersonalAllowance() {
		return personalAllowance;
	}


	public void setPersonalAllowance(double personalAllowance) {
		this.personalAllowance = personalAllowance;
	}


	public double getEpf() {
		return epf;
	}


	public void setEpf(double epf) {
		this.epf = epf;
	}


	public double getCompanyPf() {
		return companyPf;
	}


	public void setCompanyPf(double companyPf) {
		this.companyPf = companyPf;
	}


	public double getHra() {
		return hra;
	}


	public void setHra(double hra) {
		this.hra = hra;
	}


	public double getConveyenceAllowance() {
		return conveyenceAllowance;
	}


	public void setConveyenceAllowance(double conveyenceAllowance) {
		this.conveyenceAllowance = conveyenceAllowance;
	}


	public double getOtherAllowance() {
		return otherAllowance;
	}


	public void setOtherAllowance(double otherAllowance) {
		this.otherAllowance = otherAllowance;
	}


	public double getGrossSalary() {
		return grossSalary;
	}


	public void setGrossSalary(double grossSalary) {
		this.grossSalary = grossSalary;
	}


	public double getNetSalary() {
		return netSalary;
	}


	public void setNetSalary(double netSalary) {
		this.netSalary = netSalary;
	}


	public double getMonthlyTax() {
		return monthlyTax;
	}


	public void setMonthlyTax(double monthlyTax) {
		this.monthlyTax = monthlyTax;
	}


	public double getGratuity() {
		return gratuity;
	}


	public void setGratuity(double gratuity) {
		this.gratuity = gratuity;
	}
	@Override
	public String toString() {
		return "Salary [basicSalary=" + basicSalary + ", personalAllowance=" + personalAllowance + ", epf=" + epf
				+ ", companyPf=" + companyPf + ", hra=" + hra + ", conveyenceAllowance=" + conveyenceAllowance
				+ ", otherAllowance=" + otherAllowance + ", grossSalary=" + grossSalary + ", netSalary=" + netSalary
				+ ", monthlyTax=" + monthlyTax + ", gratuity=" + gratuity + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(basicSalary);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(companyPf);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(conveyenceAllowance);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(epf);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(gratuity);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(grossSalary);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(hra);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(monthlyTax);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(netSalary);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(otherAllowance);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(personalAllowance);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Salary other = (Salary) obj;
		if (Double.doubleToLongBits(basicSalary) != Double.doubleToLongBits(other.basicSalary))
			return false;
		if (Double.doubleToLongBits(companyPf) != Double.doubleToLongBits(other.companyPf))
			return false;
		if (Double.doubleToLongBits(conveyenceAllowance) != Double.doubleToLongBits(other.conveyenceAllowance))
			return false;
		if (Double.doubleToLongBits(epf) != Double.doubleToLongBits(other.epf))
			return false;
		if (Double.doubleToLongBits(gratuity) != Double.doubleToLongBits(other.gratuity))
			return false;
		if (Double.doubleToLongBits(grossSalary) != Double.doubleToLongBits(other.grossSalary))
			return false;
		if (Double.doubleToLongBits(hra) != Double.doubleToLongBits(other.hra))
			return false;
		if (Double.doubleToLongBits(monthlyTax) != Double.doubleToLongBits(other.monthlyTax))
			return false;
		if (Double.doubleToLongBits(netSalary) != Double.doubleToLongBits(other.netSalary))
			return false;
		if (Double.doubleToLongBits(otherAllowance) != Double.doubleToLongBits(other.otherAllowance))
			return false;
		if (Double.doubleToLongBits(personalAllowance) != Double.doubleToLongBits(other.personalAllowance))
			return false;
		return true;
	}


	
	}
