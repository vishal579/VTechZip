package com.cg.payroll.services;

import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
public interface PayrollServices {

	int acceptAssociateDetails(String firstName, String lastName, String emailId, String department, String designation,
			String pancard, int yearlyInvestmentUnder80C, double basicSalary, double epf, double companyPf,
			int accountNumber, String bankName, String ifscCode)throws PayrollServicesDownException;

	double calculateNetSalary(int associateId)throws AssociateDetailsNotFoundException;

	Associate getAssociateDetails(int associateId)throws AssociateDetailsNotFoundException;

	List<Associate> getAllAssociateDetails();
	boolean deleteAssociate(int associateId)throws AssociateDetailsNotFoundException;
	//boolean updateAssociate(int associateId);

	

}