package com.cg.banking.daoservices;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;

//import java.util.Random;

//import com.mysql.jdbc.PreparedStatement;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.TransactionC;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
//import com.cg.banking.utility.BankingUtility;


@Component(value="daoServices")
public class BankingDAOServicesImpl implements BankingDAOServices{
	@Autowired
	private SessionFactory sessionFactory;
	private Session session;
	private org.hibernate.Transaction transaction;
	private static Random random=new Random();
	public BankingDAOServicesImpl() throws BankingServicesDownException {

	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public int insertCustomer(Customer customer) throws SQLException {
		try {

			session=sessionFactory.openSession();
			transaction=session.beginTransaction();
			int customerId=(int) session.save(customer);
			transaction.commit();
			return customerId;
		}
		catch (HibernateException e) {
			e.printStackTrace();
			throw e;
		}
		finally {
			session.close();
		}
	}

	@Override
	public long insertAccount(int customerId, Account account) throws SQLException, CustomerNotFoundException {
		try {

			session=sessionFactory.openSession();
			transaction=session.beginTransaction();
			Customer customer=getCustomer(customerId);//(Customer) session.get(Customer.class, customerId);
			if(customer!=null){
				account.setCustomer(customer);
				account.setStatus("Active");
				long accountNo=(long) session.save(account);
				transaction.commit();
				return accountNo;
			}
			else
				throw new CustomerNotFoundException();
		}
		catch (HibernateException e) {
			e.printStackTrace();
			throw e;
		}
		finally {
			session.close();
		}

	}

	@Override
	public boolean updateAccount(int customerId, Account account) {

		session=sessionFactory.openSession();
		transaction=session.beginTransaction();
		Customer customer=(Customer) session.get(Customer.class, customerId);
		if(customer!=null){
			Account account1=(Account) session.get(Account.class, account.getAccountNo());	

			if(account1!=null){
				session.merge(account);
				transaction.commit();
				return true;
			}	
		}
		session.close();
		return false;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		session=sessionFactory.openSession();
		transaction=session.beginTransaction();
		if(getAccount(customerId, account.getAccountNo())!=null){
			int pinNumber=random.nextInt(10000);

			transaction.commit();
			return pinNumber;
		}
		session.close();
		return 0;
	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, TransactionC transactionC) {

		try {

			session=sessionFactory.openSession();
			transaction=session.beginTransaction();
			Account account=getAccount(customerId, accountNo);
			if(account!=null){
				transactionC.setAccount(account);
				session.save(transactionC);
				transaction.commit();
				return true;
			}
			else
				return false;		
		}
		catch (HibernateException e) {
			e.printStackTrace();
			throw e;
		}
		finally {
			session.close();
		}
	}

	@Override
	public boolean deleteCustomer(int customerId) {

		try {

			session=sessionFactory.openSession();
			transaction=session.beginTransaction();
			Customer customer=(Customer) session.get(Customer.class, customerId);
			if(customer!=null){
				session.delete(customer);
				transaction.commit();
				return true;
			}
			return false;
		}
		catch (HibernateException e) {
			e.printStackTrace();
			throw e;
		}
		finally {
			session.close();
		}
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {

		try {

			session=sessionFactory.openSession();
			transaction=session.beginTransaction();


			Account account=(Account) session.get(Account.class, accountNo);

			if(account!=null){
				session.delete(account);
				transaction.commit();
				return true;
			}

			return false;
		}
		catch (HibernateException e) {
			e.printStackTrace();
			throw e;
		}
		finally {
			session.close();
		}
	}

	@Override
	public Customer getCustomer(int customerId) {

		return (Customer) sessionFactory.openSession().get(Customer.class, customerId);
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		session=sessionFactory.openSession();
		Customer customer=(Customer) session.get(Customer.class, customerId);
		if(customer!=null&&customer.getAccountMap().containsKey(accountNo)==true)
			return (Account)session.get(Account.class,accountNo);
		return null;
	}

	@Override
	public List<Customer> getCustomers() {
		session=sessionFactory.openSession();
		List<Customer> customerList=session.createQuery("from Customer").list();
		session.close();
		return customerList; 
	}

	@Override
	public List<Account> getAccounts(int customerId) {
		session=sessionFactory.openSession();
		List<Account> accountList=sessionFactory.openSession().createQuery("from Account").list();
		session.close();
		return accountList;
	}

	@Override
	public List<TransactionC> getTransactions(int customerId, long accountNo) {
		session=sessionFactory.openSession();
		List<TransactionC> transactionCList=sessionFactory.openSession().createQuery("from TransactionC").list();
		session.close();
		return transactionCList;

	}


}










//BankingUtilityCookies bankingUtilityCookies=(BankingUtilityCookies) src.readObject();
//for(Customer customer:customerList)
//customerMap.put(customer.getCustomerId(), customer);
//BankingUtility.CUSTOMER_ID_COUNTER=customerList.get(customerList.size()-1).getCustomerId()+1;
//BankingUtility.ACCOUNT_NO_COUNTER;

//System.out.println(customerList.size());
//System.out.println(customer.getCustomerId()+" "+customer);
/*(System.out.println(getCustomers().size());
System.out.println(getCustomers().get(0).getAccountMap().size());
System.out.println(getCustomers().get(1).getAccountMap().size());
//System.out.println(getCustomers().size());
 * for(int i=0;i<customerList.size();i++){
					if(!(customer.getAccountMap().isEmpty()))
				}
				BankingUtility.CUSTOMER_ID_COUNTER=customerList.get(customerList.size()-1).getCustomerId()+1;
			System.out.println(BankingUtility.CUSTOMER_ID_COUNTER);
 */
//System.out.println(customer.getAccountMap().size());
//System.out.println(getCustomers().get(getCustomers().size()-1).getAccountMap().size());
//System.out.println(getCustomers().get(0).getAccountMap().size());