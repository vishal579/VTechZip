public class IfTest {
		public static void main(String[] args) {
	int[] array = {54,52,72,14,26,63,87,83,93,47,74,72};
		for (int i = 2; i !=5; i++)
			array[i] = array[(array[i] +2) % array.length];
		System.out.println(array);


		}
	}
